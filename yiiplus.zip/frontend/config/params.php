<?php
return [
    'adminEmail' => 'admin@example.com',
    'endUserPages' => ['feedback', 'feedbackthankyou', 'feedbackfromprofile'],
    'feedbackrequestEmailKeywords' => ['(customer)', '(manager)', '(feedback_link)', '(business)', '{customer}', '{manager}', '{business}', '{feedback_link}'],
];
